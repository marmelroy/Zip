Swifty News
===========

**Swifty News** is a very simple app which consumes Hacker News rss feed. It entirely build with swift.

<p align="center"><img src="screenshot.png"></p>
